.. include:: README.rst

.. toctree::
   :hidden:
   :titlesonly:
   :maxdepth: 1

   README
   extension_modules
   neuron_models
   synapses_overview
   synapse_models

source /home/travis/nest-$NEST_VERSION/bin/nest_vars.sh
export NEST_MODULE_PATH=${NEST_INSTALL_DIR}/lib/nest:$NEST_MODULE_PATH
export SLI_PATH=${NEST_INSTALL_DIR}/share/nest/sli:$SLI_PATH
